"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Heart, Users, Settings, Grid, List } from "lucide-react"
import { cars } from "@/lib/mock-data"
import { useSearchParams } from "next/navigation"

export default function BookingPage() {
  const searchParams = useSearchParams()
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [selectedBrand, setSelectedBrand] = useState<string>("all")
  const [selectedYear, setSelectedYear] = useState<string>("all")
  const [selectedCondition, setSelectedCondition] = useState<string>("all")
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const search = searchParams.get("search")
    if (search) {
      setSearchQuery(search)
    }
  }, [searchParams])

  const filteredCars = cars.filter((car) => {
    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      const searchMatch =
        car.make.toLowerCase().includes(query) ||
        car.model.toLowerCase().includes(query) ||
        car.title.toLowerCase().includes(query) ||
        car.body_type.toLowerCase().includes(query) ||
        car.color.toLowerCase().includes(query)

      if (!searchMatch) return false
    }

    // Brand filter
    if (selectedBrand !== "all" && car.make.toLowerCase() !== selectedBrand.toLowerCase()) return false

    // Year filter - Added year range filtering
    if (selectedYear !== "all") {
      if (selectedYear.includes("-")) {
        const [startYear, endYear] = selectedYear.split("-").map(Number)
        if (car.year < startYear || car.year > endYear) return false
      } else if (car.year.toString() !== selectedYear) {
        return false
      }
    }

    // Condition filter
    if (selectedCondition !== "all" && car.condition.toLowerCase() !== selectedCondition.toLowerCase()) return false

    return true
  })

  const availableYears = [...new Set(cars.map((car) => car.year))].sort((a, b) => b - a)
  const yearRanges = ["2020-2024", "2015-2019", "2010-2014", "2005-2009", "2000-2004"]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">Booking</h1>
        <div className="flex items-center space-x-2">
          <Button variant={viewMode === "grid" ? "default" : "outline"} size="icon" onClick={() => setViewMode("grid")}>
            <Grid className="h-4 w-4" />
          </Button>
          <Button variant={viewMode === "list" ? "default" : "outline"} size="icon" onClick={() => setViewMode("list")}>
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div className="flex flex-wrap gap-4">
        <Select value={selectedCondition} onValueChange={setSelectedCondition}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="New" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All</SelectItem>
            <SelectItem value="new">New</SelectItem>
            <SelectItem value="used">Used</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedBrand} onValueChange={setSelectedBrand}>
          <SelectTrigger className="w-32">
            <SelectValue placeholder="Toyota" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Brands</SelectItem>
            <SelectItem value="toyota">Toyota</SelectItem>
            <SelectItem value="porsche">Porsche</SelectItem>
            <SelectItem value="bmw">BMW</SelectItem>
            <SelectItem value="mercedes-benz">Mercedes-Benz</SelectItem>
            <SelectItem value="audi">Audi</SelectItem>
            <SelectItem value="ford">Ford</SelectItem>
            <SelectItem value="dodge">Dodge</SelectItem>
            <SelectItem value="kia">Kia</SelectItem>
            <SelectItem value="nissan">Nissan</SelectItem>
          </SelectContent>
        </Select>

        <Select value={selectedYear} onValueChange={setSelectedYear}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Year" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Years</SelectItem>
            {yearRanges.map((range) => (
              <SelectItem key={range} value={range}>
                {range}
              </SelectItem>
            ))}
            {availableYears.map((year) => (
              <SelectItem key={year} value={year.toString()}>
                {year}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <p className="text-sm text-gray-600">
        Showing {filteredCars.length} of {cars.length} results
        {searchQuery && ` for "${searchQuery}"`}
      </p>

      {/* Car Grid */}
      <div
        className={`grid gap-6 ${viewMode === "grid" ? "grid-cols-1 md:grid-cols-2 lg:grid-cols-3" : "grid-cols-1"}`}
      >
        {filteredCars.map((car) => (
          <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow">
            <CardContent className="p-0">
              <div className="relative">
                <img
                  src={car.images[0] || "/placeholder.svg"}
                  alt={`${car.make} ${car.model}`}
                  className="w-full h-48 object-cover"
                />
                <Button variant="ghost" size="icon" className="absolute top-4 right-4 bg-white/80 hover:bg-white">
                  <Heart className="h-4 w-4" />
                </Button>
              </div>

              <div className="p-4 space-y-3">
                <div>
                  <h3 className="font-semibold text-lg">
                    {car.make} {car.model}
                  </h3>
                  <p className="text-sm text-gray-500">{car.body_type}</p>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-4">
                    <span className="flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      {car.seats}
                    </span>
                    <span className="flex items-center">
                      <Settings className="w-4 h-4 mr-1" />
                      {car.transmission}
                    </span>
                  </div>
                  <span className="font-semibold text-lg">${Math.round(car.price_rwf / 1000)}/d</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredCars.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No cars found matching your criteria.</p>
          <Button
            variant="outline"
            className="mt-4 bg-transparent"
            onClick={() => {
              setSelectedBrand("all")
              setSelectedYear("all")
              setSelectedCondition("all")
              setSearchQuery("")
            }}
          >
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  )
}
