"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Settings } from "lucide-react"
import { LineChart, Line, XAxis, YAxis, ResponsiveContainer, AreaChart, Area } from "recharts"

const milesData = [
  { time: "1 PM", miles: 0 },
  { time: "2 PM", miles: 0 },
  { time: "3 PM", miles: 178 },
  { time: "4 PM", miles: 0 },
  { time: "5 PM", miles: 0 },
  { time: "6 PM", miles: 0 },
  { time: "7 PM", miles: 0 },
]

const carStatsData = [
  { time: "7 am", value: 20 },
  { time: "9 am", value: 45 },
  { time: "11 am", value: 60 },
  { time: "1 pm", value: 35 },
  { time: "3 pm", value: 50 },
  { time: "5 pm", value: 40 },
  { time: "7 pm", value: 55 },
  { time: "9 pm", value: 30 },
]

const recommendations = [
  {
    id: 1,
    name: "Mini Cooper",
    recommend: 64,
    power: "132K",
    price: "$32/h",
    image: "/mini-cooper-car.jpg",
    bgColor: "bg-yellow-100",
  },
  {
    id: 2,
    name: "Porsche 911 Carrera",
    recommend: 74,
    power: "130K",
    price: "$28/h",
    image: "/white-porsche-911.png",
    bgColor: "bg-blue-50",
  },
  {
    id: 3,
    name: "Porsche 911 Carrera",
    recommend: 74,
    power: "130K",
    price: "$28/h",
    image: "/red-porsche-911.jpg",
    bgColor: "bg-red-50",
  },
]

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Miles Statistics */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold">Miles Statistics</CardTitle>
            <div className="flex space-x-2">
              <Button variant="default" size="sm" className="bg-black text-white">
                Day
              </Button>
              <Button variant="ghost" size="sm">
                Week
              </Button>
              <Button variant="ghost" size="sm">
                Month
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-right mb-4">
              <span className="text-2xl font-bold">256 Miles</span>
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={milesData}>
                  <XAxis dataKey="time" axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Line
                    type="monotone"
                    dataKey="miles"
                    stroke="#000"
                    strokeWidth={3}
                    dot={{ fill: "#000", strokeWidth: 2, r: 4 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        {/* Car Statistics */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg font-semibold">Car Statistics</CardTitle>
            <div className="flex space-x-2">
              <Button variant="default" size="sm" className="bg-black text-white">
                Day
              </Button>
              <Button variant="ghost" size="sm">
                Week
              </Button>
              <Button variant="ghost" size="sm">
                Month
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-left mb-4">
              <span className="text-sm text-gray-500">20 February 2022</span>
            </div>
            <div className="h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={carStatsData}>
                  <XAxis dataKey="time" axisLine={false} tickLine={false} />
                  <YAxis hide />
                  <Area type="monotone" dataKey="value" stroke="#6B7280" fill="#E5E7EB" strokeWidth={2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recommendations */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {recommendations.map((car) => (
          <Card key={car.id} className={`${car.bgColor} border-0`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <Badge variant="secondary" className="bg-white/80">
                  {car.recommend}% Recommend
                </Badge>
              </div>
              <div className="mb-4">
                <img src={car.image || "/placeholder.svg"} alt={car.name} className="w-full h-24 object-contain" />
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-lg">{car.name}</h3>
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span className="flex items-center">
                    <Settings className="w-4 h-4 mr-1" />
                    {car.power}
                  </span>
                  <span className="font-semibold text-lg text-black">{car.price}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
