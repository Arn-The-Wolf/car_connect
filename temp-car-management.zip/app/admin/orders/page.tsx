import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { mockOrders } from "@/lib/mock-data"
import { Search, Plus, Edit, Eye } from "lucide-react"
import Link from "next/link"

export default function OrdersManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Orders Management</h1>
          <p className="text-muted-foreground">Track and manage customer orders</p>
        </div>
        <Button asChild>
          <Link href="/admin/orders/new">
            <Plus className="w-4 h-4 mr-2" />
            Create New Order
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Orders</CardTitle>
          <CardDescription>Complete order history and status tracking</CardDescription>
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search orders..." className="pl-10" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockOrders.map((order) => (
              <div key={order.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold text-lg">Order #{order.id}</h3>
                    <Badge
                      variant={
                        order.status === "delivered"
                          ? "default"
                          : order.status === "confirmed"
                            ? "secondary"
                            : order.status === "pending"
                              ? "outline"
                              : "destructive"
                      }
                    >
                      {order.status}
                    </Badge>
                  </div>
                  <p className="text-muted-foreground">{order.clientName}</p>
                  <p className="font-medium">{order.carName}</p>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <span>Order Date: {new Date(order.orderDate).toLocaleDateString()}</span>
                    {order.deliveryDate && <span>Delivery: {new Date(order.deliveryDate).toLocaleDateString()}</span>}
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">${order.totalAmount.toLocaleString()}</p>
                  <Badge
                    variant={
                      order.paymentStatus === "paid"
                        ? "default"
                        : order.paymentStatus === "pending"
                          ? "outline"
                          : "destructive"
                    }
                    className="mt-1"
                  >
                    {order.paymentStatus}
                  </Badge>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/orders/${order.id}`}>
                        <Eye className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/orders/${order.id}/edit`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
