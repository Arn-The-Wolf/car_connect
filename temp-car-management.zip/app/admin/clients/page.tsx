import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { mockClients } from "@/lib/mock-data"
import { Search, Plus, Edit, Mail, Phone } from "lucide-react"
import Link from "next/link"

export default function ClientsManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Clients Management</h1>
          <p className="text-muted-foreground">Manage your customer database</p>
        </div>
        <Button asChild>
          <Link href="/admin/clients/new">
            <Plus className="w-4 h-4 mr-2" />
            Add New Client
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Client Database</CardTitle>
          <CardDescription>All registered clients and their information</CardDescription>
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search clients..." className="pl-10" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockClients.map((client) => (
              <div key={client.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{client.name}</h3>
                  <div className="flex items-center gap-4 mt-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Mail className="w-4 h-4" />
                      {client.email}
                    </div>
                    <div className="flex items-center gap-1">
                      <Phone className="w-4 h-4" />
                      {client.phone}
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">{client.address}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant={client.status === "active" ? "default" : "secondary"}>{client.status}</Badge>
                    <span className="text-xs text-muted-foreground">
                      Registered: {new Date(client.registeredDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-lg font-semibold">{client.totalPurchases}</p>
                  <p className="text-sm text-muted-foreground">Total Purchases</p>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/clients/${client.id}/edit`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/clients/${client.id}/orders`}>View Orders</Link>
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
