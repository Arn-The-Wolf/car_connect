"use client"

import { useState, useEffect } from "react"
import { StatsCards } from "@/components/admin/stats-cards"
import { LiveActivityFeed } from "@/components/admin/live-activity-feed"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { mockOrders, mockCars } from "@/lib/mock-data"
import Link from "next/link"
import { RefreshCw } from "lucide-react"

export default function AdminDashboard() {
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date())
  const [isRefreshing, setIsRefreshing] = useState(false)
  const [recentOrders, setRecentOrders] = useState(mockOrders.slice(0, 5))
  const [availableCars, setAvailableCars] = useState(mockCars.filter((car) => car.status === "available").slice(0, 3))

  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate real-time updates
      const shuffledOrders = [...mockOrders].sort(() => Math.random() - 0.5).slice(0, 5)
      const shuffledCars = [...mockCars]
        .filter((car) => car.status === "available")
        .sort(() => Math.random() - 0.5)
        .slice(0, 3)

      setRecentOrders(shuffledOrders)
      setAvailableCars(shuffledCars)
      setLastUpdated(new Date())
    }, 30000) // Update every 30 seconds

    return () => clearInterval(interval)
  }, [])

  const handleRefresh = async () => {
    setIsRefreshing(true)

    // Simulate API call delay
    await new Promise((resolve) => setTimeout(resolve, 1000))

    // Refresh data
    const shuffledOrders = [...mockOrders].sort(() => Math.random() - 0.5).slice(0, 5)
    const shuffledCars = [...mockCars]
      .filter((car) => car.status === "available")
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)

    setRecentOrders(shuffledOrders)
    setAvailableCars(shuffledCars)
    setLastUpdated(new Date())
    setIsRefreshing(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back! Here's what's happening with your dealership.</p>
          <p className="text-xs text-muted-foreground mt-1">Last updated: {lastUpdated.toLocaleTimeString()}</p>
        </div>
        <Button variant="outline" size="sm" onClick={handleRefresh} disabled={isRefreshing} className="bg-transparent">
          <RefreshCw className={`w-4 h-4 mr-2 ${isRefreshing ? "animate-spin" : ""}`} />
          {isRefreshing ? "Refreshing..." : "Refresh"}
        </Button>
      </div>

      <StatsCards />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Orders */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Recent Orders
              <Badge variant="secondary" className="text-xs">
                Live
              </Badge>
            </CardTitle>
            <CardDescription>Latest customer orders and their status</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{order.clientName}</p>
                    <p className="text-sm text-muted-foreground">{order.carName}</p>
                    <p className="text-xs text-muted-foreground">{order.orderDate}</p>
                  </div>
                  <div className="text-right">
                    <Badge
                      variant={
                        order.status === "delivered"
                          ? "default"
                          : order.status === "confirmed"
                            ? "secondary"
                            : order.status === "pending"
                              ? "outline"
                              : "destructive"
                      }
                    >
                      {order.status}
                    </Badge>
                    <p className="text-sm font-medium mt-1">${order.totalAmount.toLocaleString()}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4">
              <Button variant="outline" className="w-full bg-transparent" asChild>
                <Link href="/admin/orders">View All Orders</Link>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Live Activity Feed */}
        <LiveActivityFeed />

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common administrative tasks</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start" asChild>
              <Link href="/admin/cars/new">
                <span>Add New Car</span>
              </Link>
            </Button>
            <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
              <Link href="/admin/clients/new">
                <span>Add New Client</span>
              </Link>
            </Button>
            <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
              <Link href="/admin/orders/new">
                <span>Create New Order</span>
              </Link>
            </Button>
            <Button variant="outline" className="w-full justify-start bg-transparent" asChild>
              <Link href="/admin/analytics">
                <span>View Analytics</span>
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Available Cars */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Available Cars
            <Badge variant="secondary" className="text-xs">
              Live Inventory
            </Badge>
          </CardTitle>
          <CardDescription>Current inventory ready for sale</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {availableCars.map((car) => (
              <div key={car.id} className="border rounded-lg p-4">
                <h3 className="font-medium">{car.name}</h3>
                <p className="text-sm text-muted-foreground">
                  {car.year} • {car.category}
                </p>
                <p className="text-lg font-bold text-primary mt-2">${car.price.toLocaleString()}</p>
                <Badge className="mt-2" variant="secondary">
                  {car.status}
                </Badge>
              </div>
            ))}
          </div>
          <div className="mt-4">
            <Button variant="outline" className="w-full bg-transparent" asChild>
              <Link href="/admin/cars">Manage All Cars</Link>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
