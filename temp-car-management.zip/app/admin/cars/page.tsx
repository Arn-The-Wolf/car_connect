import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { mockCars } from "@/lib/mock-data"
import { Search, Plus, Edit, Trash2 } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function CarsManagement() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Cars Management</h1>
          <p className="text-muted-foreground">Manage your vehicle inventory</p>
        </div>
        <Button asChild>
          <Link href="/admin/cars/new">
            <Plus className="w-4 h-4 mr-2" />
            Add New Car
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Vehicle Inventory</CardTitle>
          <CardDescription>All vehicles in your dealership</CardDescription>
          <div className="flex items-center gap-4">
            <div className="relative flex-1 max-w-sm">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground w-4 h-4" />
              <Input placeholder="Search cars..." className="pl-10" />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {mockCars.map((car) => (
              <div key={car.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="w-20 h-20 relative rounded-lg overflow-hidden">
                  <Image src={car.image || "/placeholder.svg"} alt={car.name} fill className="object-cover" />
                </div>

                <div className="flex-1">
                  <h3 className="font-semibold text-lg">{car.name}</h3>
                  <p className="text-muted-foreground">
                    {car.year} • {car.brand} • {car.model}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">{car.description}</p>
                  <div className="flex items-center gap-2 mt-2">
                    <Badge variant="outline">{car.category}</Badge>
                    <Badge
                      variant={car.status === "available" ? "default" : car.status === "sold" ? "secondary" : "outline"}
                    >
                      {car.status}
                    </Badge>
                  </div>
                </div>

                <div className="text-right">
                  <p className="text-2xl font-bold text-primary">${car.price.toLocaleString()}</p>
                  <p className="text-sm text-muted-foreground">{car.mileage.toLocaleString()} miles</p>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" asChild>
                      <Link href={`/admin/cars/${car.id}/edit`}>
                        <Edit className="w-4 h-4" />
                      </Link>
                    </Button>
                    <Button size="sm" variant="outline">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
