"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Car, Users, ShoppingCart, DollarSign, TrendingUp, TrendingDown } from "lucide-react"
import { mockCars, mockClients, mockOrders } from "@/lib/mock-data"

export function StatsCards() {
  const [stats, setStats] = useState<any[]>([])
  const [previousStats, setPreviousStats] = useState<any[]>([])

  useEffect(() => {
    const calculateStats = () => {
      const totalCars = mockCars.length
      const availableCars = mockCars.filter((car) => car.status === "available").length
      const totalClients = mockClients.length
      const activeClients = mockClients.filter((client) => client.status === "active").length
      const totalOrders = mockOrders.length
      const pendingOrders = mockOrders.filter((order) => order.status === "pending").length
      const totalRevenue = mockOrders
        .filter((order) => order.paymentStatus === "paid")
        .reduce((sum, order) => sum + order.totalAmount, 0)

      // Simulate some variation for dynamic effect
      const variation = () => Math.floor(Math.random() * 5) - 2 // -2 to +2

      const newStats = [
        {
          title: "Total Cars",
          value: totalCars + variation(),
          subtitle: `${availableCars + variation()} available`,
          icon: Car,
          color: "text-blue-600",
          trend: Math.random() > 0.5 ? "up" : "down",
          change: Math.floor(Math.random() * 10) + 1,
        },
        {
          title: "Total Clients",
          value: totalClients + variation(),
          subtitle: `${activeClients + variation()} active`,
          icon: Users,
          color: "text-green-600",
          trend: Math.random() > 0.3 ? "up" : "down",
          change: Math.floor(Math.random() * 15) + 1,
        },
        {
          title: "Orders",
          value: totalOrders + variation(),
          subtitle: `${pendingOrders + Math.abs(variation())} pending`,
          icon: ShoppingCart,
          color: "text-orange-600",
          trend: Math.random() > 0.4 ? "up" : "down",
          change: Math.floor(Math.random() * 8) + 1,
        },
        {
          title: "Revenue",
          value: `$${(totalRevenue + (Math.random() * 50000 - 25000)).toLocaleString()}`,
          subtitle: "This month",
          icon: DollarSign,
          color: "text-purple-600",
          trend: Math.random() > 0.2 ? "up" : "down",
          change: Math.floor(Math.random() * 20) + 5,
        },
      ]

      setPreviousStats(stats)
      setStats(newStats)
    }

    // Initial calculation
    calculateStats()

    // Update every 15 seconds for real-time feel
    const interval = setInterval(calculateStats, 15000)

    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {stats.map((stat, index) => {
        const Icon = stat.icon
        const TrendIcon = stat.trend === "up" ? TrendingUp : TrendingDown
        const trendColor = stat.trend === "up" ? "text-green-500" : "text-red-500"

        return (
          <Card key={stat.title} className="relative overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <Icon className={`h-4 w-4 ${stat.color}`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <div className="flex items-center justify-between">
                <p className="text-xs text-muted-foreground">{stat.subtitle}</p>
                <div className="flex items-center text-xs">
                  <TrendIcon className={`h-3 w-3 mr-1 ${trendColor}`} />
                  <span className={trendColor}>{stat.change}%</span>
                </div>
              </div>
            </CardContent>
            <div className="absolute top-0 right-0 w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
          </Card>
        )
      })}
    </div>
  )
}
