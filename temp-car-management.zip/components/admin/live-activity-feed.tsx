"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Car, User, ShoppingCart, DollarSign, Clock } from "lucide-react"

interface ActivityItem {
  id: string
  type: "car_added" | "order_created" | "client_registered" | "payment_received"
  message: string
  timestamp: Date
  icon: any
  color: string
}

export function LiveActivityFeed() {
  const [activities, setActivities] = useState<ActivityItem[]>([])

  useEffect(() => {
    const generateActivity = (): ActivityItem => {
      const types = ["car_added", "order_created", "client_registered", "payment_received"] as const
      const type = types[Math.floor(Math.random() * types.length)]

      const activities = {
        car_added: {
          message: `New ${["Toyota Camry", "BMW X5", "Mercedes C-Class", "Audi A4"][Math.floor(Math.random() * 4)]} added to inventory`,
          icon: Car,
          color: "text-blue-500",
        },
        order_created: {
          message: `New order #${Math.floor(Math.random() * 9999)} created by ${["John Doe", "Jane Smith", "Mike Johnson", "Sarah Wilson"][Math.floor(Math.random() * 4)]}`,
          icon: ShoppingCart,
          color: "text-orange-500",
        },
        client_registered: {
          message: `New client ${["Alex Brown", "Emma Davis", "Chris Lee", "Lisa Taylor"][Math.floor(Math.random() * 4)]} registered`,
          icon: User,
          color: "text-green-500",
        },
        payment_received: {
          message: `Payment of $${(Math.random() * 50000 + 10000).toFixed(0)} received`,
          icon: DollarSign,
          color: "text-purple-500",
        },
      }

      return {
        id: Math.random().toString(36).substr(2, 9),
        type,
        message: activities[type].message,
        timestamp: new Date(),
        icon: activities[type].icon,
        color: activities[type].color,
      }
    }

    // Add initial activities
    const initialActivities = Array.from({ length: 5 }, generateActivity)
    setActivities(initialActivities)

    // Add new activity every 20-40 seconds
    const interval = setInterval(
      () => {
        const newActivity = generateActivity()
        setActivities((prev) => [newActivity, ...prev.slice(0, 9)]) // Keep only last 10
      },
      Math.random() * 20000 + 20000,
    )

    return () => clearInterval(interval)
  }, [])

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000)

    if (seconds < 60) return `${seconds}s ago`
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`
    return `${Math.floor(seconds / 86400)}d ago`
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Live Activity Feed
          <Badge variant="secondary" className="text-xs animate-pulse">
            Live
          </Badge>
        </CardTitle>
        <CardDescription>Real-time updates from your dealership</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-80">
          <div className="space-y-3">
            {activities.map((activity) => {
              const Icon = activity.icon
              return (
                <div key={activity.id} className="flex items-start gap-3 p-3 rounded-lg border bg-card/50">
                  <Icon className={`w-4 h-4 mt-0.5 ${activity.color}`} />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-foreground">{activity.message}</p>
                    <p className="text-xs text-muted-foreground mt-1">{formatTimeAgo(activity.timestamp)}</p>
                  </div>
                </div>
              )
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  )
}
