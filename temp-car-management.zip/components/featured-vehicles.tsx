import { mockCars } from "@/lib/mock-data"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import Image from "next/image"
import Link from "next/link"

export function FeaturedVehicles() {
  // Show first 4 cars as featured
  const featuredCars = mockCars.slice(0, 4)

  return (
    <section className="py-12 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-10">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">Featured Vehicles</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Discover our handpicked selection of premium vehicles, each offering exceptional quality and performance.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {featuredCars.map((car) => (
            <Card key={car.id} className="overflow-hidden hover:shadow-lg transition-shadow duration-200">
              <CardHeader className="p-0">
                <div className="relative h-48 overflow-hidden">
                  <Image
                    src={car.image || "/placeholder.svg"}
                    alt={car.name}
                    fill
                    className="object-cover hover:scale-105 transition-transform duration-200"
                  />
                  <div className="absolute top-3 right-3">
                    <span className="bg-primary text-primary-foreground px-2 py-1 rounded-full text-xs font-medium">
                      {car.status.toUpperCase()}
                    </span>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <h3 className="font-bold text-lg mb-2 text-card-foreground">{car.name}</h3>
                <p className="text-muted-foreground text-sm mb-3 line-clamp-2">{car.description}</p>
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-bold text-primary">${car.price.toLocaleString()}</span>
                  <span className="text-sm text-muted-foreground">
                    {car.year} • {car.mileage.toLocaleString()} mi
                  </span>
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <Button className="w-full" asChild>
                  <Link href={`/cars/${car.id}`}>View Details</Link>
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="text-center">
          <Button variant="outline" size="lg" asChild>
            <Link href="/inventory">View All Vehicles</Link>
          </Button>
        </div>
      </div>
    </section>
  )
}
