import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Car, Menu, User } from "lucide-react"

export function Header() {
  return (
    <header className="absolute top-0 left-0 right-0 z-50 bg-white/10 backdrop-blur-md border-b border-white/20">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2 text-white font-bold text-xl">
            <Car className="w-8 h-8" />
            LuxuryAutos
          </Link>

          {/* Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            <Link href="/inventory" className="text-white hover:text-white/80 transition-colors">
              Inventory
            </Link>
            <Link href="/brands" className="text-white hover:text-white/80 transition-colors">
              Brands
            </Link>
            <Link href="/services" className="text-white hover:text-white/80 transition-colors">
              Services
            </Link>
            <Link href="/contact" className="text-white hover:text-white/80 transition-colors">
              Contact
            </Link>
          </nav>

          {/* Auth Buttons */}
          <div className="flex items-center gap-4">
            <Button variant="ghost" className="text-white hover:bg-white/20" asChild>
              <Link href="/signin">
                <User className="w-4 h-4 mr-2" />
                Sign In
              </Link>
            </Button>
            <Button className="hidden md:inline-flex" asChild>
              <Link href="/admin">Admin</Link>
            </Button>
            <Button variant="ghost" className="md:hidden text-white" size="icon">
              <Menu className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
