import { premiumBrands } from "@/lib/mock-data"
import Image from "next/image"

export function PremiumBrands() {
  return (
    <section className="py-16 bg-muted">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">Explore Our Premium Brands</h2>
          <button className="text-primary hover:text-primary/80 font-medium flex items-center gap-2">
            Show All Brands
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
            </svg>
          </button>
        </div>

        <div className="grid grid-cols-3 md:grid-cols-5 lg:grid-cols-9 gap-6">
          {premiumBrands.map((brand) => (
            <div
              key={brand.name}
              className="bg-card rounded-lg p-6 flex flex-col items-center justify-center hover:scale-105 transition-transform duration-200 cursor-pointer shadow-sm hover:shadow-md"
            >
              <div className="w-16 h-16 md:w-20 md:h-20 mb-3 flex items-center justify-center">
                <Image
                  src={brand.logo || "/placeholder.svg"}
                  alt={`${brand.name} logo`}
                  width={80}
                  height={80}
                  className="max-w-full max-h-full object-contain"
                />
              </div>
              <span className="text-sm font-medium text-card-foreground text-center">{brand.name.toUpperCase()}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
