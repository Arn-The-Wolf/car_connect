export interface LiveMetric {
  id: string
  name: string
  value: number
  previousValue: number
  trend: "up" | "down" | "stable"
  changePercent: number
  lastUpdated: Date
}

export class RealTimeDataService {
  private static instance: RealTimeDataService
  private metrics: Map<string, LiveMetric> = new Map()
  private subscribers: Map<string, ((metric: LiveMetric) => void)[]> = new Map()

  static getInstance(): RealTimeDataService {
    if (!RealTimeDataService.instance) {
      RealTimeDataService.instance = new RealTimeDataService()
    }
    return RealTimeDataService.instance
  }

  subscribe(metricId: string, callback: (metric: LiveMetric) => void): () => void {
    if (!this.subscribers.has(metricId)) {
      this.subscribers.set(metricId, [])
    }
    this.subscribers.get(metricId)!.push(callback)

    // Return unsubscribe function
    return () => {
      const callbacks = this.subscribers.get(metricId)
      if (callbacks) {
        const index = callbacks.indexOf(callback)
        if (index > -1) {
          callbacks.splice(index, 1)
        }
      }
    }
  }

  updateMetric(metricId: string, newValue: number): void {
    const existing = this.metrics.get(metricId)
    const previousValue = existing?.value || newValue

    const changePercent = previousValue !== 0 ? Math.round(((newValue - previousValue) / previousValue) * 100) : 0

    const trend: "up" | "down" | "stable" =
      newValue > previousValue ? "up" : newValue < previousValue ? "down" : "stable"

    const metric: LiveMetric = {
      id: metricId,
      name: metricId,
      value: newValue,
      previousValue,
      trend,
      changePercent: Math.abs(changePercent),
      lastUpdated: new Date(),
    }

    this.metrics.set(metricId, metric)

    // Notify subscribers
    const callbacks = this.subscribers.get(metricId)
    if (callbacks) {
      callbacks.forEach((callback) => callback(metric))
    }
  }

  getMetric(metricId: string): LiveMetric | undefined {
    return this.metrics.get(metricId)
  }

  // Simulate real-time data updates
  startSimulation(): void {
    const metricsToSimulate = ["cars", "clients", "orders", "revenue"]

    setInterval(() => {
      metricsToSimulate.forEach((metricId) => {
        const current = this.getMetric(metricId)?.value || Math.floor(Math.random() * 100)
        const variation = Math.floor(Math.random() * 10) - 5 // -5 to +5
        const newValue = Math.max(0, current + variation)
        this.updateMetric(metricId, newValue)
      })
    }, 10000) // Update every 10 seconds
  }
}

// Export singleton instance
export const realTimeData = RealTimeDataService.getInstance()
