// Mock data for cars - this will be replaced with database integration later
export interface Car {
  id: string
  name: string
  brand: string
  model: string
  year: number
  price: number
  image: string
  description: string
  features: string[]
  mileage: number
  fuelType: string
  transmission: string
  category: "luxury" | "suv" | "sports" | "sedan" | "electric"
  status: "available" | "sold" | "reserved"
}

export const mockCars: Car[] = [
  {
    id: "1",
    name: "Toyota Land Cruiser 300",
    brand: "Toyota",
    model: "Land Cruiser",
    year: 2024,
    price: 89000,
    image: "/toyota-land-cruiser-300-luxury-suv.jpg",
    description: "The ultimate luxury SUV with unmatched off-road capability and premium comfort.",
    features: ["4WD", "Leather Interior", "Navigation System", "Premium Sound"],
    mileage: 0,
    fuelType: "Gasoline",
    transmission: "Automatic",
    category: "suv",
    status: "available",
  },
  {
    id: "2",
    name: "Mercedes-Benz S-Class",
    brand: "Mercedes-Benz",
    model: "S-Class",
    year: 2024,
    price: 125000,
    image: "/mercedes-benz-s-class-luxury-sedan.jpg",
    description: "The pinnacle of luxury and technology in automotive excellence.",
    features: ["Massage Seats", "Ambient Lighting", "Advanced Driver Assistance", "Premium Audio"],
    mileage: 0,
    fuelType: "Gasoline",
    transmission: "Automatic",
    category: "luxury",
    status: "available",
  },
  {
    id: "3",
    name: "BMW X7",
    brand: "BMW",
    model: "X7",
    year: 2024,
    price: 98000,
    image: "/bmw-x7-luxury-suv.png",
    description: "Spacious luxury SUV with commanding presence and dynamic performance.",
    features: ["7-Seater", "Panoramic Roof", "Gesture Control", "Harman Kardon Audio"],
    mileage: 0,
    fuelType: "Gasoline",
    transmission: "Automatic",
    category: "suv",
    status: "available",
  },
  {
    id: "4",
    name: "Audi A8",
    brand: "Audi",
    model: "A8",
    year: 2024,
    price: 95000,
    image: "/audi-a8-luxury-sedan.jpg",
    description: "Sophisticated luxury sedan with cutting-edge technology and refined comfort.",
    features: ["Matrix LED Headlights", "Virtual Cockpit", "Bang & Olufsen Audio", "Air Suspension"],
    mileage: 0,
    fuelType: "Gasoline",
    transmission: "Automatic",
    category: "luxury",
    status: "available",
  },
]

export const premiumBrands = [
  { name: "Porsche", logo: "/porsche-crest.png" },
  { name: "Mercedes-Benz", logo: "/mercedes-benz-logo.jpg" },
  { name: "BMW", logo: "/bmw-logo.png" },
  { name: "Audi", logo: "/audi-logo.png" },
  { name: "Toyota", logo: "/toyota-logo.png" },
  { name: "Ford", logo: "/ford-oval-logo.png" },
  { name: "Dodge", logo: "/dodge-logo.jpg" },
  { name: "Kia", logo: "/kia-logo.png" },
  { name: "Nissan", logo: "/nissan-logo.png" },
]

export interface Client {
  id: string
  name: string
  email: string
  phone: string
  address: string
  registeredDate: string
  totalPurchases: number
  status: "active" | "inactive"
}

export interface Order {
  id: string
  clientId: string
  clientName: string
  carId: string
  carName: string
  orderDate: string
  deliveryDate?: string
  status: "pending" | "confirmed" | "delivered" | "cancelled"
  totalAmount: number
  paymentStatus: "pending" | "paid" | "refunded"
}

export const mockClients: Client[] = [
  {
    id: "1",
    name: "John Smith",
    email: "john.smith@email.com",
    phone: "+1 (555) 123-4567",
    address: "123 Main St, New York, NY 10001",
    registeredDate: "2024-01-15",
    totalPurchases: 2,
    status: "active",
  },
  {
    id: "2",
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    phone: "+1 (555) 987-6543",
    address: "456 Oak Ave, Los Angeles, CA 90210",
    registeredDate: "2024-02-20",
    totalPurchases: 1,
    status: "active",
  },
  {
    id: "3",
    name: "Michael Brown",
    email: "michael.brown@email.com",
    phone: "+1 (555) 456-7890",
    address: "789 Pine St, Chicago, IL 60601",
    registeredDate: "2024-03-10",
    totalPurchases: 0,
    status: "inactive",
  },
]

export const mockOrders: Order[] = [
  {
    id: "1",
    clientId: "1",
    clientName: "John Smith",
    carId: "1",
    carName: "Toyota Land Cruiser 300",
    orderDate: "2024-03-15",
    deliveryDate: "2024-03-25",
    status: "delivered",
    totalAmount: 89000,
    paymentStatus: "paid",
  },
  {
    id: "2",
    clientId: "2",
    clientName: "Sarah Johnson",
    carId: "2",
    carName: "Mercedes-Benz S-Class",
    orderDate: "2024-03-20",
    status: "confirmed",
    totalAmount: 125000,
    paymentStatus: "paid",
  },
  {
    id: "3",
    clientId: "1",
    clientName: "John Smith",
    carId: "3",
    carName: "BMW X7",
    orderDate: "2024-03-22",
    status: "pending",
    totalAmount: 98000,
    paymentStatus: "pending",
  },
]

export const cars = mockCars
